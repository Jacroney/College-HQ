const AWS = require('aws-sdk');
const { BedrockRuntimeClient, InvokeModelCommand } = require('@aws-sdk/client-bedrock-runtime');
require('dotenv').config();

// AWS clients
const dynamodb = new AWS.DynamoDB.DocumentClient();
const bedrock = new BedrockRuntimeClient({ region: process.env.AWS_REGION || 'us-east-1' });

// Table names
const USERS_TABLE = process.env.USERS_TABLE || 'college-hq-users';
const CONVERSATIONS_TABLE = process.env.CONVERSATIONS_TABLE || 'college-hq-conversations';

// Lambda handler
exports.handler = async (event) => {
  try {
    // Check if this is a profile request
    if (event.httpMethod && event.pathParameters) {
      return await handleProfileRequest(event);
    }
    
    // Otherwise, handle as advising request
    return await handleAdvisingRequest(event);
  } catch (error) {
    console.error('Lambda error:', error);
    return createResponse(500, { error: error.message });
  }
};

// Handle profile-related requests
async function handleProfileRequest(event) {
  const { httpMethod, pathParameters } = event;
  const userId = pathParameters?.userId;
  
  if (!userId) {
    return createResponse(400, { error: 'Missing userId in path parameters' });
  }

  switch (httpMethod) {
    case 'GET':
      return await getProfile(userId);
    case 'PUT':
      return await updateProfile(userId, event);
    default:
      return createResponse(405, { error: 'Method not allowed' });
  }
}

// Handle advising requests
async function handleAdvisingRequest(event) {
  // Parse input
  let body = event.body ? JSON.parse(event.body) : event;
  const { userId, message, conversationId } = body;
  
  if (!userId || !message) {
    return createResponse(400, { error: 'Missing userId or message' });
  }

  // Get user profile
  const userProfile = await getUserProfile(userId);
  if (!userProfile) {
    return createResponse(404, { error: 'User not found' });
  }

  // Get or create conversation
  const currentConversationId = conversationId || generateConversationId();
  const conversationHistory = await getConversationHistory(userId, currentConversationId);

  // Build context-aware prompt
  const systemPrompt = buildAdvisingSystemPrompt(userProfile);
  const messages = buildMessageHistory(conversationHistory, message);

  // Call Bedrock with proper Messages API
  const response = await callBedrock(systemPrompt, messages);

  // Store conversation
  await storeConversation(userId, currentConversationId, message, response.text);

  // Return response
  return createResponse(200, {
    agent: 'advising',
    userId,
    conversationId: currentConversationId,
    response: response.text,
    timestamp: new Date().toISOString()
  });
}

// Profile Functions

// Get user profile
async function getProfile(userId) {
  try {
    const params = {
      TableName: USERS_TABLE,
      Key: { user_id: userId }
    };
    
    const result = await dynamodb.get(params).promise();
    
    if (!result.Item) {
      // Create default profile if user doesn't exist
      const defaultProfile = createDefaultProfile(userId);
      await saveProfile(userId, defaultProfile);
      return createResponse(200, { profile: defaultProfile });
    }
    
    return createResponse(200, { profile: result.Item });
  } catch (error) {
    console.error('Error getting profile:', error);
    return createResponse(500, { error: 'Failed to get profile' });
  }
}

// Update user profile
async function updateProfile(userId, event) {
  try {
    const body = JSON.parse(event.body);
    const profileData = {
      user_id: userId,
      ...body,
      updated_at: new Date().toISOString()
    };
    
    await saveProfile(userId, profileData);
    
    return createResponse(200, { 
      message: 'Profile updated successfully',
      profile: profileData
    });
  } catch (error) {
    console.error('Error updating profile:', error);
    return createResponse(500, { error: 'Failed to update profile' });
  }
}

// Save profile to DynamoDB
async function saveProfile(userId, profileData) {
  const params = {
    TableName: USERS_TABLE,
    Item: {
      user_id: userId,
      ...profileData,
      created_at: profileData.created_at || new Date().toISOString(),
      updated_at: new Date().toISOString()
    }
  };
  
  await dynamodb.put(params).promise();
}

// Create default profile
function createDefaultProfile(userId) {
  return {
    user_id: userId,
    firstName: '',
    lastName: '',
    email: '',
    studentId: '',
    university: null,
    college: '',
    major: '',
    concentration: '',
    minor: '',
    academicYear: '',
    expectedGraduation: '',
    gpa: 0,
    totalCredits: 0,
    currentSemesterCredits: 0,
    careerGoals: [],
    learningStyle: '',
    academicInterests: [],
    advisorName: '',
    advisorEmail: '',
    advisorNotes: '',
    completedCourses: [],
    currentCourses: [],
    plannedCourses: [],
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };
}

// Helper Functions

async function getUserProfile(userId) {
  try {
    const params = {
      TableName: USERS_TABLE,
      Key: { user_id: userId }
    };
    const result = await dynamodb.get(params).promise();
    return result.Item;
  } catch (error) {
    console.error('Error getting user profile:', error);
    return null;
  }
}

async function getConversationHistory(userId, conversationId) {
  try {
    const params = {
      TableName: CONVERSATIONS_TABLE,
      Key: { user_id: userId, conversation_id: conversationId }
    };
    const result = await dynamodb.get(params).promise();
    return result.Item ? result.Item.messages : [];
  } catch (error) {
    console.error('Error getting conversation history:', error);
    return [];
  }
}

async function storeConversation(userId, conversationId, userMessage, assistantResponse) {
  try {
    const timestamp = new Date().toISOString();
    const newMessages = [
      {
        role: 'user',
        content: userMessage,
        timestamp
      },
      {
        role: 'assistant',
        content: assistantResponse,
        timestamp
      }
    ];

    // Get existing conversation
    const existingConversation = await getConversationHistory(userId, conversationId);
    const allMessages = [...existingConversation, ...newMessages];

    const params = {
      TableName: CONVERSATIONS_TABLE,
      Key: { user_id: userId, conversation_id: conversationId },
      UpdateExpression: 'SET messages = :messages, agent_type = :agent_type, updated_at = :updated_at',
      ExpressionAttributeValues: {
        ':messages': allMessages,
        ':agent_type': 'advising',
        ':updated_at': timestamp
      }
    };

    await dynamodb.update(params).promise();
  } catch (error) {
    console.error('Error storing conversation:', error);
  }
}

function buildAdvisingSystemPrompt(userProfile) {
  return `You are an expert academic advisor for college students. You provide personalized course recommendations and academic guidance.

Student Profile:
- Name: ${userProfile.email}
- University: ${userProfile.university}
- Major: ${userProfile.major}
- Concentration: ${userProfile.concentration || 'Not specified'}
- Year: ${userProfile.year}

Your Role:
- Provide specific, actionable course recommendations
- Consider prerequisite requirements and course sequences
- Help with degree planning and graduation timelines
- Suggest extracurricular activities and opportunities
- Be encouraging and supportive

Guidelines:
- Always consider the student's specific major and year
- Ask clarifying questions when needed
- Provide reasoning for your recommendations
- Mention prerequisites and course difficulty when relevant
- Keep responses concise but comprehensive
- If you need specific course catalog information, acknowledge this limitation

Respond in a friendly, professional tone as an academic advisor would.`;
}

function buildMessageHistory(conversationHistory, newMessage) {
  // Convert conversation history to Messages API format
  const messages = conversationHistory.map(msg => ({
    role: msg.role,
    content: msg.content
  }));

  // Add new user message
  messages.push({
    role: 'user',
    content: newMessage
  });

  return messages;
}

async function callBedrock(systemPrompt, messages) {
  try {
    const modelId = 'anthropic.claude-3-sonnet-20240229-v1:0';
    
    const requestBody = {
      anthropic_version: 'bedrock-2023-05-31',
      system: systemPrompt,
      messages: messages,
      max_tokens: 1024,
      temperature: 0.7
    };

    const command = new InvokeModelCommand({
      modelId,
      contentType: 'application/json',
      accept: 'application/json',
      body: JSON.stringify(requestBody)
    });

    const response = await bedrock.send(command);
    const responseBody = JSON.parse(new TextDecoder().decode(response.body));
    
    return {
      text: responseBody.content[0].text,
      usage: responseBody.usage
    };
  } catch (error) {
    console.error('Bedrock error:', error);
    throw new Error('Failed to generate response');
  }
}

function generateConversationId() {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const random = Math.random().toString(36).substring(2, 8);
  return `conv-${timestamp}-${random}`;
}

function createResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
      'Access-Control-Allow-Methods': 'POST,OPTIONS'
    },
    body: JSON.stringify(body)
  };
}

// Local testing
if (require.main === module) {
  (async () => {
    // Mock user profile for testing
    const mockUserProfile = {
      user_id: 'test-user',
      email: 'test@university.edu',
      university: 'State University',
      major: 'Computer Science',
      concentration: 'Software Engineering',
      year: 'Junior'
    };

    // Mock getUserProfile for testing
    const originalGetUserProfile = getUserProfile;
    getUserProfile = async (userId) => mockUserProfile;

    const event = {
      userId: 'test-user',
      message: 'What classes should I take next semester for my CS major?'
    };

    const result = await exports.handler(event);
    console.log('Test result:', JSON.stringify(result, null, 2));
  })();
}